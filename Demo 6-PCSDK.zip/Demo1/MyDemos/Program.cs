﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using Microsoft.Store.PartnerCenter.Models;
using Microsoft.Store.PartnerCenter.Models.Customers;
using Microsoft.Store.PartnerCenter.Models.Orders;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.Store.PartnerCenter;
using Microsoft.Store.PartnerCenter.Exceptions;
using Microsoft.Store.PartnerCenter.Models.Query;
using Microsoft.Store.PartnerCenter.Extensions;
using Microsoft.Store.PartnerCenter.Models.Offers;

namespace MyDemos
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //login Azure AD, for partner center sdk, you can use the "common" as the tenant id
                var aadAuthenticationResult = Program.LoginToAad("common", SettingsHelper.PartnerCenterApiResourceId).Result;

                //set to use the public partner center api
                PartnerService.Instance.ApiRootUrl = SettingsHelper.PartnerCenterApiEndpoint;

                //get the credential
                var authToken = new AuthenticationToken(aadAuthenticationResult.AccessToken, aadAuthenticationResult.ExpiresOn);
                IPartnerCredentials credentials = PartnerCredentials.Instance.GenerateByUserCredentials(SettingsHelper.ClientId, authToken);
                //get the partner operations
                IPartner partner = PartnerService.Instance.CreatePartnerOperations(credentials);

                //[Test]#1:Create new customner
                //var customer = CreateCustomer(partner);

                //[Test]#2: Query paged customers with keyword in company name
                //QueryCustomers(partner, "EMD", 100);

                //[Test]#3: Create offer for special customer, you can get customer id from test 2
                //GetOffers(partner, 500);

                //[Test]#4: Create offer for special customer, you can get customer id from test 2
                //var customerId = customer.Id;
                //PlaceOrder(partner, customerId);

                Console.WriteLine("Press [Enter] to exit");
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("error source：" + ex.Source);
                Console.WriteLine("error message：" + ex.Message);
                Console.WriteLine("Press [Enter] to exit");
                Console.ReadLine();
            }
        }

        /// <summary>
        /// Login in azure ad and get the credential
        /// </summary>
        /// <param name="tenantId">the domain</param>
        /// <param name="resource">the resouce to get access token</param>
        /// <returns></returns>
        private static async Task<AuthenticationResult> LoginToAad(string tenantId, string resource)
        {
            // auth from azure ad 
            var addAuthority = new UriBuilder(SettingsHelper.AadAuthority + tenantId);
            UserCredential userCredentials = new UserCredential(SettingsHelper.UserId,
                                                    SettingsHelper.UserPassword);
            AuthenticationContext authContext = new AuthenticationContext(addAuthority.Uri.AbsoluteUri);
            return await authContext.AcquireTokenAsync(resource,
                                                       SettingsHelper.ClientId,
                                                       userCredentials);
        }
        /// <summary>
        /// Query paged customers 
        /// </summary>
        /// <param name="partner"></param>
        /// <param name="pageSize">page size</param>
        private static void QueryCustomers(IPartner partner, int pageSize)
        {
            var myQuery = QueryFactory.Instance.BuildIndexedQuery(pageSize, 0);
            var customersPage = partner.Customers.Query(myQuery);


            var customersEnumerator = partner.Enumerators.Customers.Create(customersPage);
            int i = 0, pageNumber = 0;
            while (customersEnumerator.HasValue)
            {
                ++pageNumber;
                var customers = customersEnumerator.Current;
                StringBuilder report = new StringBuilder();
                report.AppendFormat("The #{0} page exists {1} customers\n", pageNumber, customers.TotalCount);
                report.AppendFormat("Index,Customer ID,Name,Domain:\n");
                foreach (var customer in customers.Items)
                {
                    ++i;
                    try
                    {
                        report.AppendFormat("\n#{0},{1},{2},{3}\n", i, customer.Id, customer.CompanyProfile.CompanyName, customer.CompanyProfile.Domain);

                        // get the customer's subcriptions
                        var subscriptions = partner.Customers.ById(customer.Id).Subscriptions.Get();
                        if (subscriptions.TotalCount == 0)
                        {
                            report.AppendFormat("\nNo subscription exists\n");
                        }
                        else
                        {
                            report.AppendFormat("\nSubscription ID,Subscription Name,Subscription Quantity\n");
                            foreach (var subscription in subscriptions.Items)
                            {
                                //add the subscription
                                report.AppendFormat("{0},{1},{2}\n", subscription.Id, subscription.FriendlyName, subscription.Quantity);
                            }
                        }

                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("Succeed to get the #{0} customer at the #{1} page!", i, pageNumber);
                    }
                    catch (PartnerException)
                    {
                        //ignore some 403 errors related to Commerce and BEC 
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Fail to get the #{0} customer at the #{1} page!", i, pageNumber);
                    }

                    Console.ForegroundColor = ConsoleColor.White;
                }
                //print the report
                Console.WriteLine(report);

                customersEnumerator.Next();
            }



            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();
        }

        /// <summary>
        /// Query paged customers via keyword in company name
        /// </summary>
        /// <param name="partner"></param>
        /// <param name="keywords">the keyword in company name</param>
        /// <param name="pageSize">page size</param>
        private static void QueryCustomers(IPartner partner, string keywords, int pageSize)
        {
            // query the customer via keyword in company name
            var fieldFilter = new SimpleFieldFilter(CustomerSearchField.CompanyName.ToString(), FieldFilterOperation.StartsWith, keywords);
            var myQuery = QueryFactory.Instance.BuildIndexedQuery(pageSize, 0, fieldFilter);
            var customersPage = partner.Customers.Query(myQuery);


            var customersEnumerator = partner.Enumerators.Customers.Create(customersPage);
            int i = 0, pageNumber = 0;
            while (customersEnumerator.HasValue)
            {
                ++pageNumber;
                var customers = customersEnumerator.Current;
                StringBuilder report = new StringBuilder();
                report.AppendFormat("The #{0} page exists {1} customers\n", pageNumber, customers.TotalCount);
                report.AppendFormat("Index,Customer ID,Name,Domain:\n");
                foreach (var customer in customers.Items)
                {
                    ++i;
                    try
                    {
                        report.AppendFormat("\n#{0},{1},{2},{3}\n", i, customer.Id, customer.CompanyProfile.CompanyName, customer.CompanyProfile.Domain);

                        // get the customer's subcriptions
                        var subscriptions = partner.Customers.ById(customer.Id).Subscriptions.Get();
                        if (subscriptions.TotalCount == 0)
                        {
                            report.AppendFormat("\nNo subscription exists\n");
                        }
                        else
                        {
                            report.AppendFormat("\nSubscription ID,Subscription Name,Subscription Quantity\n");
                            foreach (var subscription in subscriptions.Items)
                            {
                                //add the subscription
                                report.AppendFormat("{0},{1},{2}\n", subscription.Id, subscription.FriendlyName, subscription.Quantity);
                            }
                        }

                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("Succeed to get the #{0} customer at the #{1} page!", i, pageNumber);
                    }
                    catch (PartnerException)
                    {
                        //ignore some 403 errors related to Commerce and BEC 
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Fail to get the #{0} customer at the #{1} page!", i, pageNumber);
                    }

                    Console.ForegroundColor = ConsoleColor.White;
                }
                //print the report
                Console.WriteLine(report);

                customersEnumerator.Next();
            }



            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();
        }
        /// <summary>
        /// Create new customer
        /// </summary>
        /// <param name="partnerOperations"></param>
        /// <returns></returns>
        private static Customer CreateCustomer(IPartner partnerOperations)
        {
            //set the customer's information
            var domainPrefix = "EMD18031402";
            string strCompnayName = "EMD18031402";
            Customer newCustomer = new Customer()
            {
                // set the company profile
                CompanyProfile = new CustomerCompanyProfile()
                {
                    // set the domain 
                    Domain = string.Format(CultureInfo.InvariantCulture, "{0}.onmicrosoft.com", domainPrefix),
                    // set company name
                    CompanyName = strCompnayName
                },
                //set the billing profile
                BillingProfile = new CustomerBillingProfile
                {
                    Culture = "en-US",
                    Language = "en",
                    FirstName = "Test",
                    LastName = "EMD",
                    Email = string.Format("daniel@{0}.onmicrosoft.com", domainPrefix),
                    CompanyName = strCompnayName,

                    DefaultAddress = new Address()
                    {
                        FirstName = "Test",
                        LastName = "EMD",
                        AddressLine1 = "1 Microsoft Way",
                        AddressLine2 = "Building 1",
                        City = "Redmond",
                        State = "WA",
                        Country = "US",
                        PostalCode = "98052",
                        PhoneNumber = "415-555-1212"
                    }
                }
            };
            return partnerOperations.Customers.Create(newCustomer);
        }

        /// <summary>
        /// get the available offers by country
        /// </summary>
        /// <param name="partnerOperations"></param>
        /// <param name="size"></param>
        private static void GetOffers(IPartner partnerOperations, Int32 size)
        {
            var offers = partnerOperations.Offers.ByCountry("US").Get(0, size);

            StringBuilder report = new StringBuilder();
            report.Append("Offer ID, Category Name, SalesGroupId, Offer Name\n");
            foreach (Offer offer in offers.Items)
            {
                report.AppendFormat(" {0}, {1}, {2},{3}\n", offer.Id, offer.Category.Name, offer.SalesGroupId, offer.Name);
            }

            // list offers
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("The available offers...");
            Console.WriteLine(report);
        }

        /// <summary>
        /// Create the subscription/order for customer,like azure ,powerbi ,office365 etc
        /// </summary>
        /// <param name="partnerOperations"></param>
        /// <param name="customerId">the customer id</param>
        public static void PlaceOrder(IPartner partnerOperations, string customerId)
        {

            //you can add multi order items in same order
            //but only offers with same salesgroupid can put into same order.
            //for example , if you try to put the powerbi pro and azure subscritpipon into same order, error will occur
            var lineItems = new List<OrderLineItem>();
            /* 
             *
            lineItems.Add(new OrderLineItem
            {
                LineItemNumber = 0,
                OfferId = "800F4F3B-CFE1-42C1-9CEA-675512810488",
                FriendlyName = "Power BI Pro - MSFT",
                Quantity = 1
            });

            lineItems.Add(new OrderLineItem
            {
                LineItemNumber = 1,
                OfferId = "A6ACBC1C-9D2A-482A-ABDA-DFB9285E301E",
                FriendlyName = "Power BI Pro - Government",
                Quantity = 1
            });
            */


            //create the azure subscription
            lineItems.Add(new OrderLineItem
            {
                LineItemNumber = 0,
                OfferId = "MS-AZR-0146P",
                FriendlyName = "CSP Microsoft Azure",
                Quantity = 1
            });


            // create order
            var order = new Order
            {
                ReferenceCustomerId = customerId,
                LineItems = lineItems
            };


            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("create order...");

            try
            {
                partnerOperations.Customers.ById(customerId).Orders.Create(order);
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("order created successfully!");
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("error occurs", ex.Message);
            }
        }
    }
}
